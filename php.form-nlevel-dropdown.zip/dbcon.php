<?php

$db = @mysql_connect('localhost:3366', 'root', 'root');
@mysql_select_db('ajax_categories',$db);	
