<?php

require("app.config.php");

$sql = "SELECT * FROM test_member WHERE id=:id";
$db->bind("id",1);
$dataList = $db->query($sql);
$total = $db->getTotal();
echo "Records Selected: ".$total."<br>";
print_r($dataList);
