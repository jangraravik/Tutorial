<?php

if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) { die('You cannot directly access this file'); };

require_once("framework/class_session.php");
require_once("framework/class_database.php");
require_once("framework/class_sitelog.php");
require_once("framework/helper.php");

define('__ROOT__', dirname(dirname(__FILE__)));
date_default_timezone_set("Asia/Calcutta");


set_error_handler("myPHPErrorHandler");
define("ERROR_SEND",'LOG'); /* LOG | MAIL */
define("SITE_ERROR_TO_MAIL",'ravi.jangra@goweb99.com');


$db = new DatabaseConnection();
$siteLog = new Log();