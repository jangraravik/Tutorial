<?php

require("app.config.php");


$sql = "INSERT INTO test_member(fname,lname,email,status) VALUES(:fname,:lname,:email,:status)";
$data = array("fname"=>"User","lname"=>"Kumar","email"=>"email@email.com","status"=>"1");
$db->query($sql,$data);
$newId = $db->getNewId();
echo "New Record Inserted: ".$newId;