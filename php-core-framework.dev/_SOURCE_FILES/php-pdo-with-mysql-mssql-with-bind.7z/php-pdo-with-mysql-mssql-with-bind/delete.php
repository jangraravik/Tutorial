<?php

require("app.config.php");

$sql = "DELETE FROM test_member WHERE Id = :id";
$data = array("id"=>5);
$total = $db->query($sql,$data); 
echo "Records Deleted: ".$total;
