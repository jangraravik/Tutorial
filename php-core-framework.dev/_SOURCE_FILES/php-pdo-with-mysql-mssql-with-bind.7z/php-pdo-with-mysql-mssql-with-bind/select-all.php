<?php

require("app.config.php");

$sql = "SELECT * FROM test_member";
$dataList = $db->query($sql); 
$total = $db->getTotal(); 
echo "Records Selected: ".$total."<br>";
print_r($dataList);
