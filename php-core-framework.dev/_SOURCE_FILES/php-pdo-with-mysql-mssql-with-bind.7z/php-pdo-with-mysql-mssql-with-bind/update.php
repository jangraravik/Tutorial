<?php

require("app.config.php");

$sql = "UPDATE test_member SET fname = :fn WHERE Id = :id";
$data = array("fn"=>"Update","id"=>3);
$total = $db->query($sql,$data); 
echo "Records Updated: ".$total;