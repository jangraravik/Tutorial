<?php
require_once('dbcon.php');

echo $sn->get('captcha_code');

if(isset($_POST['submit']) && $_POST['submit']){
	if($_POST["captcha_code"] == $sn->get('captcha_code')){
		echo "Success!";
	} else {
		echo "Incorrect captcha entered";
	}
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Captcha</title>
</head>

<body>
<form method="post">
 <img src="captcha.php">
 <input type="text" name="captcha_code">
 <input type="submit" action="submit">
</form>
</body>
</html>
