;<?php if (basename($_SERVER['PHP_SELF']) == basename(__FILE__)) { die('You cannot directly access this file'); }; ?>
ACTIVE_DB = 'MYSQL'

[MYSQL]
dbtype = 'mysql'
dbhost = 'localhost:3366'
dbuser = 'root'
dbpass = 'root'
dbname = 'test'

[MSSQL]
dbtype = 'sqlsrv'
dbhost = 'sql.ivacationonline.com,1533'
dbuser = 'goweb99'
dbpass = 'Fj7N-dxsqL&GsCey'
dbname = 'vrpms_sitecms'