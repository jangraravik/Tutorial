<?php

define ("DB_HOST", "localhost");
define ("DB_USER", "root");
define ("DB_PASS","root");
define ("DB_NAME","testing_import_excel");

$db = mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME) or die("Couldn't make connection.");

set_include_path(get_include_path() . PATH_SEPARATOR . 'classes/');
include 'PHPExcel/IOFactory.php';

$inputFileName = 'users.xlsx'; 

try {
	$objPHPExcel = PHPExcel_IOFactory::load($inputFileName);
} catch(Exception $e) {
	die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
}

$allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);
$totalRecordInSheet = count($allDataInSheet);

/* Start from 2 row exclude field Heading */
for($i=2;$i<=$totalRecordInSheet;$i++){
$userName = trim($allDataInSheet[$i]["A"]);
$userEmail = trim($allDataInSheet[$i]["B"]);
$userMobile = trim($allDataInSheet[$i]["C"]);

$query = "SELECT name FROM users WHERE name = '".$userName."' AND email = '".$userEmail."' AND mobile = '".$userMobile."'";
$sql = mysqli_query($db,$query);
$recResult = mysqli_fetch_array($sql);
$existName = $recResult["name"];

if($existName=="") {
		$sql = "INSERT INTO users SET name = '".$userName."', email = '".$userEmail."', mobile = '".$userMobile."'";
		mysqli_query($db,$sql);
		echo 'Record has been added<br />';
	} else {
		echo 'Record already exist<br />';
	}
}
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Import Excel file data in mysql</title>
</head>
<body>
</body>
<html>