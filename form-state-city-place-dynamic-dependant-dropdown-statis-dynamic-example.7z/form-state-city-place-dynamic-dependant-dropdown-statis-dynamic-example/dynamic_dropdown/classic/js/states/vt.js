function populate(form)
{
form.options.length = 0;
form.options[0] = new Option("Select a county of Vermont",'');
form.options[1] = new Option("Addison County","Addison County");
form.options[2] = new Option("Bennington County","Bennington County");
form.options[3] = new Option("Caledonia County","Caledonia County");
form.options[4] = new Option('Chittenden County','Chittenden County');
form.options[5] = new Option('Essex County','Essex County');
form.options[6] = new Option('Franklin County','Franklin County');
form.options[7] = new Option('Grand Isle County','Grand Isle County');
form.options[8] = new Option('Lamoille County','Lamoille County');
form.options[9] = new Option('Orange County','Orange County');
form.options[10] = new Option('Orleans County','Orleans County');
form.options[11] = new Option('Rutland County','Rutland County');
form.options[12] = new Option('Washington County','Washington County');
form.options[13] = new Option('Windham County','Windham County');
form.options[14] = new Option('Windsor County','Windsor County');
}