function populate(form)
{
form.options.length = 0;
form.options[0] = new Option("Select a county of Arizona","");
form.options[1] = new Option("Apache County","Apache County");
form.options[2] = new Option("Cochise County","Cochise County");
form.options[3] = new Option("Coconino County","Coconino County");
form.options[4] = new Option("Gila County","Gila County");
form.options[5] = new Option("Graham County","Graham County");
form.options[6] = new Option("Greenlee County","Greenlee County");
form.options[7] = new Option("La Paz County","La Paz County");
form.options[8] = new Option("Maricopa County","Maricopa County");
form.options[9] = new Option("Mohave County","Mohave County");
form.options[10] = new Option("Navajo County","Navajo County");
form.options[11] = new Option("Pima County","Pima County");
form.options[12] = new Option("Pinal County","Pinal County");
form.options[13] = new Option("Santa Cruz County","Santa Cruz County");
form.options[14] = new Option("Yavapai County","Yavapai County");
form.options[15] = new Option("Yuma County","Yuma County");
}