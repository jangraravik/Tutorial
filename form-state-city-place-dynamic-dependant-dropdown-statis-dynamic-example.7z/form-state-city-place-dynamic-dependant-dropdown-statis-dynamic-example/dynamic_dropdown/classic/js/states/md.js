function populate(form)
{
form.options.length = 0;
form.options[0] = new Option("Select a county of Maryland","");
form.options[1] = new Option("Allegany County","Allegany County");
form.options[2] = new Option("Anne Arundel County","Anne Arundel County");
form.options[3] = new Option("Baltimore County","Baltimore County");
form.options[4] = new Option("Baltimore City","Baltimore City");
form.options[5] = new Option("Calvert County","Calvert County");
form.options[6] = new Option("Caroline County","Caroline County");
form.options[7] = new Option("Carroll County","Carroll County");
form.options[8] = new Option("Cecil County","Cecil County");
form.options[9] = new Option("Charles County","Charles County");
form.options[10] = new Option("Dorchester County","Dorchester County");
form.options[11] = new Option("Frederick County","Frederick County");
form.options[12] = new Option("Garrett County","Garrett County");
form.options[13] = new Option("Harford County","Harford County");
form.options[14] = new Option("Howard County","Howard County");
form.options[15] = new Option("Kent County","Kent County");
form.options[16] = new Option("Montgomery County","Montgomery County");
form.options[17] = new Option("Prince George's County","Prince George's County");
form.options[18] = new Option("Queen Anne's County","Queen Anne's County");
form.options[19] = new Option("Saint Mary's County","Saint Mary's County");
form.options[20] = new Option("Somerset County","Somerset County");
form.options[21] = new Option("Talbot County","Talbot County");
form.options[22] = new Option("Washington County","Washington County");
form.options[23] = new Option("Wicomico County","Wicomico County");
form.options[24] = new Option("Worcester County","Worcester County");
}